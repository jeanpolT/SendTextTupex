package com.example.firestore;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ActionBar;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.gsm.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.local.QueryData;

import java.util.HashMap;
import java.util.Map;

import io.opencensus.tags.Tag;

class User {

    public String username;
    public String email;

    public User() {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public User(String username, String email) {
        this.username = username;
        this.email = email;
    }
}


public class MainActivity extends AppCompatActivity {

    //Views
    EditText mTitleEt, mDescriptionEt, mshow;
    Button mSaveBtn, mListBtn;

    //progress dialog
    ProgressDialog pd;

    //Firestore instance
    FirebaseFirestore db;


    ////////////////////////////////////7ENvio de SMS
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;
    EditText textMsg,textPhoneNo;
    String msg, phoneNo;
    Button send;
    //////////////////////////////////////
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /////////////////////////////////////77
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED)
        {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS))
            {

            }
            else
            {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        }

        textMsg = findViewById(R.id.textMsg);
        textPhoneNo = findViewById(R.id.textPhoneNo);
        send = findViewById(R.id.send);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendTextMenssage();
            }
        });
        /////////////////////////////////////
        /////////////////////////////////////

        TextView listaData;

        mshow = findViewById(R.id.show);
        listaData = findViewById(R.id.show22);



        /////////////////////////////////////

        //Initialize views with its xml
        mTitleEt = findViewById(R.id.titleEt);
        mDescriptionEt = findViewById(R.id.descriptionEt);
        mSaveBtn = findViewById(R.id.saveBtn);
        mListBtn = findViewById(R.id.listBtn);

        //peogresss dialog

        pd = new ProgressDialog(this);

        //Firestore
        db = FirebaseFirestore.getInstance();

        //click buttono to udload data
        mSaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //input data
                String title = mTitleEt.getText().toString().trim();
                String description = mDescriptionEt.getText().toString().trim();

                //funtion call to upload data
                uploadData(title,description);
            }
        });




        mListBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                ShowData();
            }
        });

    }

    ///////////////////////////////////77
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {

        switch (requestCode)
        {
            case MY_PERMISSIONS_REQUEST_SEND_SMS:
            {
                if (grantResults.length>0 && grantResults[0] == PackageManager.PERMISSION_GRANTED )
                {
                    Toast.makeText(this, "Permiso concedido", Toast.LENGTH_LONG ).show();
                }
                else
                {
                    Toast.makeText(this, "Why did't you permit me idiot!", Toast.LENGTH_LONG).show();
                }
            }
        }
    }

    protected void sendTextMenssage()
    {
        msg = textMsg.getText().toString();
        phoneNo = textPhoneNo.getText().toString();

        android.telephony.SmsManager smsManager = android.telephony.SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNo,null,msg,null,null);
        Toast.makeText(this,"Enviado", Toast.LENGTH_SHORT).show();

    }
    ///////////////////////////////////77
    private void ShowData(){
        //show data
        db.collection("users")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {

                        if (task.isSuccessful()){
                            for (QueryDocumentSnapshot document : task.getResult()){
                                pd.dismiss();
                                Toast.makeText(MainActivity.this, "mensaje" + document.getString("nombre"),Toast.LENGTH_SHORT);
                                mshow.setText("nuevo mensaje: " + document.getData());

                                //textMsg
                                //textPhoneNo

                            }

                        } else {
                            pd.dismiss();
                            Toast.makeText(MainActivity.this,"Error",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void uploadData(String title, String description){
        //set title of progress bar
        pd.setTitle("agregado a firestore");

        //show progress
        pd.show();

        Map<String, Object> user = new HashMap<>();
        user = new HashMap<>();

        user.put("nombre", "jeanpool");
        user.put("numero", title);
        user.put("mensaje",description);
        user.put("validarr","0");

        //add this data

        db.collection("users")
                .add(user)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        pd.dismiss();
                        Toast.makeText(MainActivity.this,"Upload...",Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        pd.dismiss();
                        Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
