package com.example.firestore;

public class Model {
    String nombre, mensaje,numero,validarr;

    public Model(){

    }

    public  Model(String nombre, String mensaje, String numero, String validarr){
        this.nombre = nombre;
        this.mensaje = mensaje;
        this.numero = numero;
        this.validarr = validarr;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getValidarr() {
        return validarr;
    }

    public void setValidarr(String validarr) {
        this.validarr = validarr;
    }

}
