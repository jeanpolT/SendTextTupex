//var fullname 	= document.getElementById("fullname");
//var numero 		= document.getElementById("numero");
//var texto 		= document.getElementById("texto");
//var getElementById

var fullname = document.getElementById('fullname');

//var name = document.getElementsByTagName('fullname');

function submitClick() {

	var mensaje = fullname.value;

	firebaseRef.push().set(mensaje);

//	firebaseRef.child("fullname".set(fullname.value));
//	firebaseRef.child("fullname".set("abc"));
}


//function submitClick() {
	//firebaseRef.child(text).set();
//	event.preventDefault(); // Prevenimos el comportamiento por defecto de un formulario (Enviar por URL los parametros)
//    const fullname = document.getElementById('fullname'); // Obtenemos la referencia a cada uno de nuestros elementos del formulario
//    const numero = document.getElementById('numero');
//    const texto = document.querySelector('texto');

//    const data = {
//        'fullname': nombre.value,
//        'numero': numero.value,
//        'texto': texto.value
//    }; // Creamos un objecto con todos los elementos de nuestro formulario.
//    saveContactForm(data); // Enviamos la información obtenida por el usuario a la función que se encargara de guardar la información en Firebase
//    form.reset();
//}

//function saveContactForm(datos) {
    //firebase.database().ref('contact').push(datos) // Hacemos referencia al método database de el SDK y hacemos referencia el nombre del objeto que contendrá nuestros registros y empujamos los nuevos envios de datos
//      .then(function(){
//        alert('mensaje guardado'); // Si la petición es correcta y almaceno los datos mostramos un mensaje al usuario.
//      })
//      .catch(function(){
//        alert('mensaje No guardado'); // En caso de ocurrir un error le mostramos al usuario que ocurrió un error.
//      });
//  };
